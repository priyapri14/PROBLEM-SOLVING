#calculate difference
def difference(arr, n):
	d1 = 0
	d2 = 0
	for i in range(0, n):
		for j in range(0, n):
	
			if (i == j):
				d1 += arr[i][j]
			if (i == n - j - 1):
				d2 += arr[i][j]
	return abs(d1 - d2)
n = 3
# assigning value for  matrix
arr = [[3, 2, 2],
	[6 , 2, 2],
	[5, 9, 7]]
print(arr)
print("the result is " )
print(difference(arr, n))
	
