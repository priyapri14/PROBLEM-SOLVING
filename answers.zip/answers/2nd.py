Available ='kkoabdllwoshHorthWdll'
# e is missing , for that we are using ascii value 
missing_value = chr(101)
# confirm ascii value of e is 101 
print("The ASCII value of '" + missing_value + "' is", ord(missing_value))
print("H" + missing_value + "llo world")
